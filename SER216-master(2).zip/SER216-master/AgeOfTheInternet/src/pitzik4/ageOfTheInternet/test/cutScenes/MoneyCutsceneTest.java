package pitzik4.ageOfTheInternet.test.cutScenes;

import pitzik4.ageOfTheInternet.cutScenes.MoneyCutscene;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
