package pitzik4.ageOfTheInternet;

import pitzik4.ageOfTheInternet.graphics.Renderable;

public interface RenderableTickable extends Renderable, Tickable {

}
