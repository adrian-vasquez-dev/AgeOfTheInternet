package test.graphics;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ AnimationTest.class, BackgroundTest.class, BlueFrameTest.class, ConfettiParticleTest.class,
		ExplosionParticleTest.class, InfoBoxTest.class, MoneyParticleTest.class, ScreenTest.class, SpriteTest.class })
public class AllGraphicsTests {

}
