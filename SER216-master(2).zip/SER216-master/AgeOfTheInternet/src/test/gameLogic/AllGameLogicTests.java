package test.gameLogic;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ ButtonTest.class, GameTest.class, HackerTest.class, LevelTest.class, LoseScreenTest.class,
		MenuTest.class, PauseScreenTest.class, PlayerTest.class, TitleScreenTest.class, XButtonTest.class })
public class AllGameLogicTests {

}
