package test.gameLogic;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import pitzik4.ageOfTheInternet.Game;
import pitzik4.ageOfTheInternet.Menu;

public class MenuTest {

	@Test
	public void testMenu() {
		String str[] = {"hi","bye","good"};
		Menu m = new Menu(new Game(), 1, 2, 200, str, "hello");
		assertEquals(m.getX(), 1);
		assertEquals(m.getY(), 2);
	}

	@Test
	public void testTick() {
		String str[] = {"hi","bye","good"};
		Menu m = new Menu(new Game(), 1, 2, 200, str, "hello");
		assertEquals(m.exited, false);
	}

	@Test
	public void testGetX() {
		String str[] = {"hi","bye","good"};
		Menu m = new Menu(new Game(), 1, 2, 200, str, "hello");
		assertEquals(m.getX(), 1);
	}

	@Test
	public void testGetY() {
		String str[] = {"hi","bye","good"};
		Menu m = new Menu(new Game(), 1, 2, 200, str, "hello");
		assertEquals(m.getY(), 2);
	}

	@Test
	public void testGetXOffset() {
		String str[] = {"hi","bye","good"};
		Menu m = new Menu(new Game(), 1, 2, 200, str, "hello");
		assertEquals(m.getXOffset(), 0);
	}

	@Test
	public void testGetYOffset() {
		String str[] = {"hi","bye","good"};
		Menu m = new Menu(new Game(), 1, 2, 200, str, "hello");
		assertEquals(m.getYOffset(), 0);
	}
}
