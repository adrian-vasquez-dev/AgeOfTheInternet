package test.gameLogic;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import pitzik4.ageOfTheInternet.Button;
import pitzik4.ageOfTheInternet.Game;

public class ButtonTest {
	public static Game game;
	public static Button button; 

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		game = new Game();
		button = new Button(game, 10, 11, 12, "button");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		game = null;
		button = null;
	}

	@Test
	public void testButton() {
		assertEquals(button.getX(), 10);
		assertEquals(button.getY(), 11);
		assertEquals(button.getWidth(), 12);
	}
	
	@Test
	public void testGetXOffset() {
		assertEquals(button.getXOffset(), 0); // Method simply returns 0
	}

	@Test
	public void testGetYOffset() {
		assertEquals(button.getXOffset(), 0); // Method simply returns 0
	}

}
