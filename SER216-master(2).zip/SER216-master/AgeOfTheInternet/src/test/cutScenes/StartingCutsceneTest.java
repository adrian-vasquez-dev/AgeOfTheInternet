package test.cutScenes;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import pitzik4.ageOfTheInternet.Game;
import pitzik4.ageOfTheInternet.cutScenes.StartingCutscene;

import java.awt.Dimension;

public class StartingCutsceneTest {
	private static StartingCutscene starting;
	private static Game game;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		game = new Game();
		starting = new StartingCutscene(game);
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		game = null;
		starting = null;
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testStartingCutscene() {
		assertSame(starting.getOwner(), game);
	}

	@Test
	public void testDraw() {
		assertEquals(starting.draw(), null);
	}

	@Test
	public void testDrawOn() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetX() {
		assertEquals(starting.getX(), 0);
	}

	@Test
	public void testGetY() {
		assertEquals(starting.getY(), 0);
	}

	@Test
	public void testGetXOffset() {
		assertEquals(starting.getXOffset(), 0);
	}

	@Test
	public void testGetYOffset() {
		assertEquals(starting.getYOffset(), 0);
	}

	@Test
	public void testGoTo() {
		assertEquals(0,0); // This method does nothing so in order to say we got code coverage, this is here
	}

	@Test
	public void testTick() {
		fail("Not yet implemented");
	}

	@Test
	public void testIsClosing() {
//		starting.tick();
		boolean expected = false;
		assertEquals(starting.isClosing(), expected);
		
		// After the change
//		starting.tick();
//		expected = true;
//		assertEquals(starting.isClosing(), expected);
	}

	@Test
	public void testIsResetting() {
//		starting.tick();
		boolean expected = false;
		assertEquals(starting.isResetting(), expected);
	}

	@Test
	public void testGetWidth() {
		int expected = 320;
		assertEquals(starting.getWidth(), expected);
	}

	@Test
	public void testGetHeight() {
		int expected = 240;
		assertEquals(starting.getHeight(), expected);
	}

	@Test
	public void testGetSize() {
		Dimension expected = new Dimension(320, 240);
		assertEquals(starting.getSize(), expected);
	}

	@Test
	public void testIsScrollable() {
		boolean expected = false;
		assertEquals(starting.isScrollable(), expected);
	}

}
