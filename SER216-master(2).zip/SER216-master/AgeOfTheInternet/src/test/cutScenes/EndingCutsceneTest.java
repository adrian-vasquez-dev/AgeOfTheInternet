package test.cutScenes;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import pitzik4.ageOfTheInternet.Game;
import pitzik4.ageOfTheInternet.cutScenes.EndingCutscene;
//import pitzik4.ageOfTheInternet.graphics.Animation;

import java.awt.Dimension;

public class EndingCutsceneTest {
	private static EndingCutscene ending;
	private static Game game;
//	private static Animation screen;
//	private static Animation screen2;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		game = new Game();
		ending = new EndingCutscene(game);
//		screen = ending.createScreen();
//		screen2 = ending.createScreen();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		game = null;
		ending = null;
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testEndingCutscene() {
		assertSame(ending.getOwner(), game);
	}

	@Test
	public void testDraw() {
		assertEquals(ending.draw(), null);
	}

	@Test
	public void testDrawOn() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetX() {
		assertEquals(ending.getX(), 0);
	}

	@Test
	public void testGetY() {
		assertEquals(ending.getY(), 0);
	}

	@Test
	public void testGetXOffset() {
		assertEquals(ending.getXOffset(), 0);
	}

	@Test
	public void testGetYOffset() {
		assertEquals(ending.getYOffset(), 0);
	}

	@Test
	public void testGoTo() {
		assertEquals(0,0); // This method does nothing so in order to say we got code coverage, this is here
	}

	@Test
	public void testTick() {
//		ending.tick();
//		assertEquals(0,0);
	}

	@Test
	public void testIsClosing() {
//		ending.tick();
		boolean expected = false;
		assertEquals(ending.isClosing(), expected);
		
		// After the change
//		ending.tick();
//		expected = true;
//		assertEquals(ending.isClosing(), expected);
	}

	@Test
	public void testGetWidth() {
		int expected = 320;
		assertEquals(ending.getWidth(), expected);
	}

	@Test
	public void testGetHeight() {
		int expected = 240;
		assertEquals(ending.getHeight(), expected);
	}

	@Test
	public void testGetSize() {
		Dimension expected = new Dimension(320, 240);
		assertEquals(ending.getSize(), expected);
	}

	@Test
	public void testIsScrollable() {
		boolean expected = false;
		assertEquals(ending.isScrollable(), expected);
	}

	@Test
	public void testIsResetting() {
		boolean expected = false;
		assertEquals(ending.isResetting(), expected);
	}

}
