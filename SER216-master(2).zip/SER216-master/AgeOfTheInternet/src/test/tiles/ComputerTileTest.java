package test.tiles;

import static org.junit.Assert.*;

import org.junit.Test;

import pitzik4.ageOfTheInternet.tiles.ComputerTile;

public class ComputerTileTest {

	@Test
	public void testIsEvil() {
		assertEquals(new ComputerTile(0,0).isEvil(), false);
	}

	@Test
	public void testHackCost() {
		assertEquals(new ComputerTile(0,0).hackCost(), 5);
	}

	@Test
	public void testHack() {
		ComputerTile h = new ComputerTile(0,0);
		assertEquals(h.riCliMenuOptions[0], "Hack");
	}

}
