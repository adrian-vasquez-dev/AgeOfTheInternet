package test.tiles;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class CorporationTileTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testFurtherDraw() {
		assert(true);
	}

	@Test
	public void testBeOwned() {
		assert(true);
	}

	@Test
	public void testBeEvil() {
		assert(true);
	}

	@Test
	public void testStartEvil() {
		assert(true);
	}

	@Test
	public void testDeEvil() {
		assert(true);
	}

	@Test
	public void testIsEvil() {
		assert(true);
	}

	@Test
	public void testCanBeEvil() {
		assert(true);
	}

	@Test
	public void testUnHack() {
		assert(true);
	}

	@Test
	public void testHackCost() {
		assert(true);
	}

	@Test
	public void testCorporationTileIntInt() {
		assert(true);
	}

	@Test
	public void testCorporationTileIntIntGame() {
		assert(true);
	}

	@Test
	public void testResetStats() {
		assert(true);
	}

	@Test
	public void testTick() {
		assert(true);
	}

	@Test
	public void testHack() {
		assert(true);
	}

}
