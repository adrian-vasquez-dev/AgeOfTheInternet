package test.tiles;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import pitzik4.ageOfTheInternet.Game;
import pitzik4.ageOfTheInternet.tiles.EndTile;

public class EndTileTest {

	@Test
	public void testHackCost() {
		assertEquals(new EndTile(0,0, new Game()).hackCost(), 10);
	}
}
