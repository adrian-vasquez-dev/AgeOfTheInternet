package test.tiles;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import pitzik4.ageOfTheInternet.tiles.HackerTile;

public class HackerTileTest {

	@Test
	public void testFurtherDraw() {
		assertEquals(0, 0); // method is blank
	}

	@Test
	public void testIsEvil() {
		assertEquals(new HackerTile(0,0).isEvil(), true);
	}

	@Test
	public void testUnHack() {
		HackerTile h = new HackerTile(0,0);
		assertEquals(h.initiatedUnhacking, false);
		h.unHack();
		assertEquals(h.initiatedUnhacking, false);
		
	}

	@Test
	public void testHackCost() {
		assertEquals(new HackerTile(0,0).hackCost(), -10);
	}

	@Test
	public void testResetStats() {
		
		HackerTile h = new HackerTile(0,0);
		
		assertEquals(h.slowestUnhack, 80);
		assertEquals(h.fastestUnhack, 60);
		h.resetStats();
		assertEquals(h.slowestUnhack, 200);
		assertEquals(h.fastestUnhack, 120);
	}

	@Test
	public void testHack() {
		HackerTile h = new HackerTile(0,0);
		assertEquals(h.riCliMenuOptions[0], "Hack");
	}

	@Test
	public void testIsOwned() {
		assertEquals(new HackerTile(0,0).isOwned(), false);
	}

	@Test
	public void testInverseUnhackProbability() {
		assertEquals(new HackerTile(0,0).inverseUnhackProbability(), 20);		
	}

}
