package test.tiles;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import pitzik4.ageOfTheInternet.Game;
import pitzik4.ageOfTheInternet.tiles.ConnectionTile;

public class ConnectionTileTest {
	public static Game game;
	public static ConnectionTile connection;
	public static int[] neighbors;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		game = new Game();
		// Cannot initialize a ConnectionTile object because of infrastructure needed
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}


	@Test
	public void testHackCost() {
		// Simply returns 0
	}

	@Test
	public void testConnectableTiles() {
		// Tested in Manual Testing
	}

	@Test
	public void testConnectionTile() {
		// Tested in Manual testing
	}

	@Test
	public void testTick() {
		// Method is blank
	}

}
