package test.tiles;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ BrokenConnectionTileTest.class, ComputerTileTest.class, ConnectionTileTest.class,
		CorporationTileTest.class, EndTileTest.class, HackerTileTest.class, HomeTileTest.class })
public class AllTileTests {

}
