package test.tiles;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import pitzik4.ageOfTheInternet.tiles.BrokenConnectionTile;

public class BrokenConnectionTileTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testHackCost() {
		int[] x = {0,0,0,0};
		byte j = 0;
		assertEquals(new BrokenConnectionTile(1, 0, x, j).hackCost(), 0);
	}

	@Test
	public void testBrokenConnectionTile() {
		int[] x = {0,0,0,0};
		byte j = 0;
		assertEquals(new BrokenConnectionTile(1, 0, x, j).x, 1);
		assertEquals(new BrokenConnectionTile(0, 1, x, j).y, 1);
	}

	@Test
	public void testTick() {
		int[] x = {0,0,0,0};
		byte j = 0;
		assertEquals(new BrokenConnectionTile(0, 0, x, j).POSITIONAL_SPRITES[0], 13); // blank method
	}

	@Test
	public void testNotifyOwnedChange() {
		int[] x = {0,0,0,0};
		byte j = 0;
		assertEquals(new BrokenConnectionTile(0, 0, x, j).notifyOwnedChange(0), true);
	}

	@Test
	public void testUsable() {
		int[] x = {0,0,0,0};
		byte j = 0;
		assertEquals(new BrokenConnectionTile(0, 0, x, j).usable(), true);
	}

}
