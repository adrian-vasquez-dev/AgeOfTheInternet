package test.graphics;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import pitzik4.ageOfTheInternet.Game;
import pitzik4.ageOfTheInternet.graphics.Screen;

public class ScreenTest {
	public static Game game;
	public static Screen screen;
	public static final int POOR_RES = 2;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		game = new Game();
		screen = new Screen(game);
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		game = null;
		screen = null;
	}

	@Test
	public void testScreen() {
		assertEquals(screen.getWidth(), game.getWidth()/POOR_RES+1);
		assertEquals(screen.getHeight(), game.getHeight()/POOR_RES+1);
	}

	@Test
	public void testFadeTo() {
		assertEquals(screen.getFade(), 0); // Initial fade value
		screen.fadeTo(5);
		assertEquals(screen.getFade(), 5); // Fade value after function
	}

	@Test
	public void testGetScrollX() {
		assertEquals(screen.getScrollX(), 0);
	}

	@Test
	public void testGetScrollY() {
		assertEquals(screen.getScrollY(), 0);
	}

}
