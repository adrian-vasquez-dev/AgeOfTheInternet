package test.graphics;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import pitzik4.ageOfTheInternet.graphics.InfoBox;
import pitzik4.ageOfTheInternet.graphics.Renderable;

public class InfoBoxTest {
	
	@Test
	public void testInfoBox() {
		InfoBox ib = new InfoBox(0, 1, 480, 600, null, "stuff");		
	}

	@Test
	public void testGetX() {
		InfoBox ib = new InfoBox(0, 1, 480, 600, null, "stuff");
		assertEquals(ib.getX(), 0);
	}

	@Test
	public void testGetY() {
		InfoBox ib = new InfoBox(0, 0, 480, 600, null, "stuff");
		assertEquals(ib.getY(), 0);
	}

	@Test
	public void testGetXOffset() {
		InfoBox ib = new InfoBox(0, 1, 480, 600, null, "stuff");
		assertEquals(ib.getXOffset(), 0);
	}

	@Test
	public void testGetYOffset() {
		InfoBox ib = new InfoBox(0, 1, 480, 600, null, "stuff");
		assertEquals(ib.getYOffset(), 0);
	}

	@Test
	public void testGo() {
		InfoBox ib = new InfoBox(0, 1, 480, 600, null, "stuff");
		assertNotEquals(ib.stop(), null);
		assertEquals(ib.isGoing(), false);
	}

	@Test
	public void testStop() {
		InfoBox ib = new InfoBox(0, 1, 480, 600, null, "stuff");
		assertNotEquals(ib.stop(), null);
		assertEquals(ib.isGoing(), false);
	}

	@Test
	public void testFinish() {
		InfoBox ib = new InfoBox(0, 1, 480, 600, null, "stuff");
		assertNotEquals(ib.finish(), null);
	}

	@Test
	public void testIsGoing() {
		InfoBox ib = new InfoBox(0, 1, 480, 600, null, "stuff");
		assertEquals(ib.isGoing(), false);
	}

}
