package test.graphics;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class AnimationTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testAnimationRenderableArrayIntArrayIntIntBoolean() {
		assert(true);
	}

	@Test
	public void testAnimationRenderableArrayIntIntIntBoolean() {
		assert(true);
	}

	@Test
	public void testAnimationIntArrayIntArrayIntIntBoolean() {
		assert(true);
	}

	@Test
	public void testAnimationIntArrayIntIntIntBoolean() {
		assert(true);
	}

	@Test
	public void testDraw() {
		assert(true);
	}

	@Test
	public void testDrawOn() {
		assert(true);
	}

	@Test
	public void testGetX() {
		assert(true);
	}

	@Test
	public void testGetY() {
		assert(true);
	}

	@Test
	public void testGetXOffset() {
		assert(true);
	}

	@Test
	public void testGetYOffset() {
		assert(true);
	}

	@Test
	public void testGoTo() {
		assert(true);
	}

	@Test
	public void testGo() {
		assert(true);
	}

	@Test
	public void testStop() {
		assert(true);
	}

	@Test
	public void testTick() {
		assert(true);
	}

}
