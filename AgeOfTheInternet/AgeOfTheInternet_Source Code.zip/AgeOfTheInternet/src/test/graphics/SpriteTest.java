package test.graphics;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import pitzik4.ageOfTheInternet.Game;
import pitzik4.ageOfTheInternet.graphics.Sprite;

public class SpriteTest {
	public static Game game;
	public static Sprite sprite;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		game = new Game();
		sprite = new Sprite(80);
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		game = null;
		sprite = null;
	}

	@Test
	public void testGetX() {
		assertEquals(sprite.getX(), 0);
	}

	@Test
	public void testGetY() {
		assertEquals(sprite.getY(), 0);
	}

	@Test
	public void testGetXOffset() {
		assertEquals(sprite.getXOffset(), 0);
	}

	@Test
	public void testGetYOffset() {
		assertEquals(sprite.getYOffset(), 0);
	}

	@Test
	public void testGoTo() {
		sprite.goTo(10, 10);
		assertEquals(sprite.getX(), 10);
		assertEquals(sprite.getY(), 10);
	}


}
