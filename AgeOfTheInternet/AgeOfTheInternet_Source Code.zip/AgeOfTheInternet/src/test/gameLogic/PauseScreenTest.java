package test.gameLogic;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import pitzik4.ageOfTheInternet.Game;
import pitzik4.ageOfTheInternet.PauseScreen;

public class PauseScreenTest {

	@Test
	public void testPauseScreenIntIntIntIntGame() {
		PauseScreen ps = new PauseScreen(1, 2, 600, 480, new Game());
	}

	@Test
	public void testGetX() {
		PauseScreen ps = new PauseScreen(1, 2, 600, 480, new Game());
		assertEquals(ps.getX(), 1);
	}

	@Test
	public void testGetY() {
		PauseScreen ps = new PauseScreen(1, 2, 600, 480, new Game());
		assertEquals(ps.getY(), 2);
	}

	@Test
	public void testGetXOffset() {
		PauseScreen ps = new PauseScreen(1, 2, 600, 480, new Game());
		assertEquals(ps.getXOffset(), 0);
	}

	@Test
	public void testGetYOffset() {
		PauseScreen ps = new PauseScreen(1, 2, 600, 480, new Game());
		assertEquals(ps.getYOffset(), 0);
	}
}
