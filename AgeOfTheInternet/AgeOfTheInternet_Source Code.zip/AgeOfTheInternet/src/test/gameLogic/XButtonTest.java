package test.gameLogic;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import pitzik4.ageOfTheInternet.Game;
import pitzik4.ageOfTheInternet.XButton;

public class XButtonTest {
	public static Game game;
	public static XButton xButton;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		game = new Game();
		xButton = new XButton(game, 10, 10);
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Test
	public void testXButton() {
		assertEquals(xButton.getX(), 10);
		assertEquals(xButton.getY(), 10);
	}

	@Test
	public void testGetXOffset() {
		assertEquals(xButton.getXOffset(), 0);
	}

	@Test
	public void testGetYOffset() {
		assertEquals(xButton.getYOffset(), 0);
	}

}
