package test.gameLogic;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import pitzik4.ageOfTheInternet.Game;
import pitzik4.ageOfTheInternet.LoseScreen;

public class LoseScreenTest {

	@Test
	public void testLoseScreen() {
		LoseScreen l = new LoseScreen(new Game(), 1, 2, 600, 480, "You lose");
		assertNotEquals(l.retry, null);
	}

	@Test
	public void testGetX() {
		LoseScreen l = new LoseScreen(new Game(), 1, 2, 600, 480, "You lose");
		assertEquals(l.getX(), 1);
	}

	@Test
	public void testGetY() {
		LoseScreen l = new LoseScreen(new Game(), 1, 2, 600, 480, "You lose");
		assertEquals(l.getY(), 2);
	}

	@Test
	public void testGetXOffset() {
		LoseScreen l = new LoseScreen(new Game(), 1, 2, 600, 480, "You lose");
		assertEquals(l.getXOffset(), 0);
	}

	@Test
	public void testGetYOffset() {
		LoseScreen l = new LoseScreen(new Game(), 1, 2, 600, 480, "You lose");
		assertEquals(l.getYOffset(), 0);
	}
}
