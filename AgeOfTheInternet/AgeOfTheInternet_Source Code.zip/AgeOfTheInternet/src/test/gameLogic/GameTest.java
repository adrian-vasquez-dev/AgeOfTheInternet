package test.gameLogic;

import static org.junit.Assert.*;

import java.awt.Dimension;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import pitzik4.ageOfTheInternet.Game;
import pitzik4.ageOfTheInternet.Level;
import pitzik4.ageOfTheInternet.Stage;
import pitzik4.ageOfTheInternet.TitleScreen;
import pitzik4.ageOfTheInternet.cutScenes.EndingCutscene;
import pitzik4.ageOfTheInternet.cutScenes.HackerCutscene;
import pitzik4.ageOfTheInternet.cutScenes.MoneyCutscene;
import pitzik4.ageOfTheInternet.cutScenes.StartingCutscene;
import pitzik4.ageOfTheInternet.graphics.Screen;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.awt.event.MouseEvent;
import java.awt.event.WindowEvent;
import java.awt.event.KeyEvent;



public class GameTest {
	private static Game game;
	public static Stage currentLevel;
	public static Stage[] levels = new Stage[12];
	public MouseEvent mseEvt;
	public WindowEvent winEvt;
	public KeyEvent keyEvt;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		game = new Game();
		game.init();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testIsFocusable() {
		boolean expected = true;
		assertEquals(game.isFocusable(), expected);
	}

	@Test
	public void testInit() {
		Game game = new Game();
		game.init();
		assertEquals(game.getWidth(), 640);
		assertEquals(game.getHeight(), 480);
	}

	@Test
	public void testStart() {
		Game game = new Game();
		game.init();
		game.start();
	}

	@Test
	public void testStop() {

		Game g = new Game();
		g.init();
		g.start();
		g.stop();
	}

	@Test
	public void testRemakeLevel() {
  
		// these will never pass because 'expected' is stored in a different mem address
		
		Stage expected = new StartingCutscene(game);
		expected = null;
		assertEquals(game.remakeLevel(12), expected);

		Game g = new Game();
		g.init();
		g.start();
		g.remakeLevel(3);
	}

	@Test
	public void testPaintGraphics() {
		Game g = new Game();
		g.init();
		g.start();
	}

	@Test
	public void testRun() {
		Game g = new Game();
		g.init();
		g.start();
		assertEquals(g.stopping, false);
	}

	@Test
	public void testTick() {
		Game g = new Game();
		g.init();
		g.start();
		g.tick();
	}

	@Test
	public void testAddTickable() {
		Game g = new Game();
		g.init();
		g.start();
	}

	@Test
	public void testRemoveTickable() {
		Game g = new Game();
		g.init();
		g.start();
		g.removeTickable(new Object());
	}

	@Test
	public void testBeginGame() {
		Game g = new Game();
		g.init();
		g.start();
		g.beginGame();
	}

	@Test
	public void testNextLevel() {
		Game g = new Game();
		g.init();
		g.start();
		g.nextLevel();
	}

	@Test
	public void testResetLevel() {
		Game g = new Game();
		g.init();
		g.start();
		g.resetLevel();
	}

	@Test
	public void testWindowClosed() {
		game.windowClosed(winEvt);
		boolean expected = true;
		assertEquals(game.paused, expected);
	}

	@Test
	public void testWindowClosing() {
		game.windowClosing(winEvt);
		boolean expected = true;
		assertEquals(game.paused, expected);
	}

	@Test
	public void testWindowDeactivated() {
		game.windowDeactivated(winEvt);
		boolean expected = true;
		assertEquals(game.paused, expected);
	}

	@Test
	public void testWindowDeiconified() {
		game.windowDeiconified(winEvt);
	}

	@Test
	public void testWindowIconified() {
		game.windowIconified(winEvt);
		boolean expected = true;
		assertEquals(game.paused, expected);
	}

	@Test
	public void testWindowOpened() {
		game.windowOpened(winEvt); // Empty useless method
	}

	@Test
	public void testKeyTyped() {
		assertEquals(0, 0); // Empty useless method
	}

	@Test
	public void testMouseClicked() {
		assertEquals(0, 0); // Empty useless method
	}

	@Test
	public void testMouseEntered() {
		assertEquals(0, 0); // Empty useless method
	}

	@Test
	public void testMouseExited() {
		assertEquals(0, 0); // Empty useless method
	}

	@Test
	public void testMouseReleased() {
		game.mouseReleased(mseEvt);	
	}

	@Test
	public void testMouseInsideOfIntIntIntInt() {
		boolean expected = false;
		assertEquals(game.mouseInsideOf(0, 0, 0, 0), expected);
		
		expected = true;
		assertEquals(game.mouseInsideOf(-5, -5, 10, 10), expected);
	}

	@Test
	public void testMouseInsideOfIntIntIntIntBoolean() {
		boolean expected = false;
		assertEquals(game.mouseInsideOf(0, 0, 0, 0, false), expected);
		
		expected = true;
		assertEquals(game.mouseInsideOf(-5, -5, 10, 10, true), expected);
	}

	@Test
	public void testPause() {
		Game g = new Game();
		g.init();
		g.start();
		g.pause(true);
		assertEquals(g.paused, true);
		g.pause(false);
		assertEquals(g.paused, false);
	}

	@Test
	public void testFocusGained() {
		game.pause(false);
		boolean expected = false;
		assertEquals(game.paused, expected);
	}
}
