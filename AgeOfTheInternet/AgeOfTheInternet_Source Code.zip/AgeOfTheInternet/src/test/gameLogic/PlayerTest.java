package test.gameLogic;

import static org.junit.Assert.*;

import java.awt.Point;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import pitzik4.ageOfTheInternet.Game;
import pitzik4.ageOfTheInternet.Player;
import pitzik4.ageOfTheInternet.tiles.HackerTile;

public class PlayerTest {
	public static Game game;
	public static Player player;
	public static Point[] path;
	public static int num;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		game = new Game();
		player = new Player(10, 10, path);
		num = 3 + HackerTile.hackersOwned;
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		game = null;
		player = null;
	}

	@Test
	public void testStepSize() {
		assertEquals(player.stepSize(), num);
	}

	@Test
	public void testPlayer() {
		assertEquals(player.getX(), 10);
		assertEquals(player.getY(), 10);
	}

	@Test
	public void testGetXOffset() {
		assertEquals(player.getXOffset(), 0);
	}

	@Test
	public void testGetYOffset() {
		assertEquals(player.getYOffset(), 0);
	}

	@Test
	public void testGo() {
		player.go();
		assertEquals(player.going, true);
	}

	@Test
	public void testStop() {
		player.stop();
		assertEquals(player.going, false);
	}

}
