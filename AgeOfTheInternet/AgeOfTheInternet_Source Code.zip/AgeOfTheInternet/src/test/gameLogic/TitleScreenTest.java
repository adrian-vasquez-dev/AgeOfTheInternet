package test.gameLogic;
import pitzik4.ageOfTheInternet.TitleScreen;
import pitzik4.ageOfTheInternet.Game;
import static org.junit.Assert.*;

import java.awt.Dimension;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import pitzik4.ageOfTheInternet.Game;
import pitzik4.ageOfTheInternet.TitleScreen;

public class TitleScreenTest {

	@Test
	public void testTitleScreen() {
		TitleScreen t = new TitleScreen(new Game());
	}

	@Test
	public void testGetX() {
		TitleScreen t = new TitleScreen(new Game());
		assertEquals(t.getX(), 0);
	}

	@Test
	public void testGetY() {
		TitleScreen t = new TitleScreen(new Game());
		assertEquals(t.getY(), 0);
	}

	@Test
	public void testGetXOffset() {
		TitleScreen t = new TitleScreen(new Game());
		assertEquals(t.getXOffset(), 0);
	}

	@Test
	public void testGetYOffset() {
		TitleScreen t = new TitleScreen(new Game());
		assertEquals(t.getYOffset(), 0);
	}

	@Test
	public void testIsClosing() {
		TitleScreen t = new TitleScreen(new Game());
		assertEquals(t.isClosing(), false);
	}

	@Test
	public void testGetWidth() {
		TitleScreen t = new TitleScreen(new Game());
		assertEquals(t.getWidth(), 320);
	}

	@Test
	public void testGetHeight() {
		TitleScreen t = new TitleScreen(new Game());
		assertEquals(t.getHeight(), 240);
	}

	@Test
	public void testGetSize() {
		TitleScreen t = new TitleScreen(new Game());
		assertEquals(t.getSize(),  new Dimension(320, 240));
	}

	@Test
	public void testIsScrollable() {
		TitleScreen t = new TitleScreen(new Game());
		assertEquals(t.isScrollable(), false);
	}

	@Test
	public void testIsResetting() {
		TitleScreen t = new TitleScreen(new Game());
		assertEquals(t.isResetting(), false);
	}

}
