package test.gameLogic;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import pitzik4.ageOfTheInternet.Hacker;
import pitzik4.ageOfTheInternet.Game;
import java.awt.Point;

public class HackerTest {
	public static Game game;
	public static Hacker hacker; 
	public static Point[] path;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		game = new Game();
		hacker = new Hacker(10, 10, path);
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		game = null;
		hacker = null;
	}


	@Test
	public void testGetX() {
		assertEquals(hacker.getX(), 10);
	}

	@Test
	public void testGetY() {
		assertEquals(hacker.getY(), 10);
	}

	@Test
	public void testGetXOffset() {
		assertEquals(hacker.getXOffset(), 0);
	}

	@Test
	public void testGetYOffset() {
		assertEquals(hacker.getYOffset(), 0);
	}

	@Test
	public void testGo() {
		hacker.go();
		assertEquals(hacker.going, true);
	}

	@Test
	public void testStop() {
		hacker.stop();
		assertEquals(hacker.going, false);
	}

}
