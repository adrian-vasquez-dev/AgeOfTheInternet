package test.gameLogic;

import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import pitzik4.ageOfTheInternet.Game;
import pitzik4.ageOfTheInternet.Level;

public class LevelTest {
	

	@Test
	public void testTick() {
		
	}

	@Test
	public void testGetX() throws IOException {
		
	}

	@Test
	public void testGetY() throws IOException {
	}

	@Test
	public void testGetXOffset() throws IOException {
	}

	@Test
	public void testGetYOffset() {
		
	}

	@Test
	public void testGoTo() {
	}

	@Test
	public void testIsClosing() {
	}

	@Test
	public void testGetWidth() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetHeight() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetSize() {
		fail("Not yet implemented");
	}

	@Test
	public void testIsOwnedIntInt() {
		fail("Not yet implemented");
	}

	@Test
	public void testIsOwnedTile() {
		fail("Not yet implemented");
	}

	@Test
	public void testNeighbors() {
		fail("Not yet implemented");
	}

	@Test
	public void testConnectionNeighbors() {
		fail("Not yet implemented");
	}

	@Test
	public void testCanBeHackedBy() {
		fail("Not yet implemented");
	}

	@Test
	public void testCanBeEviledBy() {
		fail("Not yet implemented");
	}

	@Test
	public void testAllCanBeHackedBy() {
		fail("Not yet implemented");
	}

	@Test
	public void testAllCanBeEviledBy() {
		fail("Not yet implemented");
	}

	@Test
	public void testWhatCanBeEviledBy() {
		fail("Not yet implemented");
	}

	@Test
	public void testWhatCanBeEviled() {
		fail("Not yet implemented");
	}

	@Test
	public void testHack() {
		fail("Not yet implemented");
	}

	@Test
	public void testHack2() {
		fail("Not yet implemented");
	}

	@Test
	public void testEvil() {
		fail("Not yet implemented");
	}

	@Test
	public void testUnhack() {
		fail("Not yet implemented");
	}

	@Test
	public void testDeevil() {
		fail("Not yet implemented");
	}

	@Test
	public void testIsScrollable() {
		fail("Not yet implemented");
	}

	@Test
	public void testWin() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetRAM() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetRAM() {
		fail("Not yet implemented");
	}

	@Test
	public void testIsResetting() {
		fail("Not yet implemented");
	}

	@Test
	public void testLose() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddPlayer() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddHacker() {
		fail("Not yet implemented");
	}

	@Test
	public void testRemovePlayerTile() {
		fail("Not yet implemented");
	}

	@Test
	public void testRemoveHackerTile() {
		fail("Not yet implemented");
	}

	@Test
	public void testEnsureConnected() {
		fail("Not yet implemented");
	}

	@Test
	public void testRemovePlayerPlayer() {
		fail("Not yet implemented");
	}

	@Test
	public void testRemoveHackerHacker() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetMoney() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetMoney() {
		fail("Not yet implemented");
	}

	@Test
	public void testUpgradeHome() {
		fail("Not yet implemented");
	}

	@Test
	public void testCanUpgrade() throws IOException {
	}

	@Test
	public void testHackHacker() {
		fail("Not yet implemented");
	}

	@Test
	public void testIsHackerOwned() {
		fail("Not yet implemented");
	}

	@Test
	public void testIsEvilIntInt() {
		fail("Not yet implemented");
	}

	@Test
	public void testIsEvilTile() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddOwnedComputer() {
		fail("Not yet implemented");
	}

	@Test
	public void testRemoveOwnedComputer() {
		fail("Not yet implemented");
	}

	@Test
	public void testEmitMoneyParticleFrom() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetLevel() {
	}

}
