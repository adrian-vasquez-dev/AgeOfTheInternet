package test.cutScenes;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ EndingCutsceneTest.class, HackerCutsceneTest.class, MoneyCutsceneTest.class,
		StartingCutsceneTest.class })
public class AllCutSceneTests {

}
