package test.cutScenes;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import pitzik4.ageOfTheInternet.Game;
import pitzik4.ageOfTheInternet.cutScenes.HackerCutscene;

import java.awt.Dimension;

public class HackerCutsceneTest {
	private static HackerCutscene hacker;
	private static Game game;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		game = new Game();
		hacker = new HackerCutscene(game);
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testHackerCutscene() {
		assertSame(hacker.getOwner(), game);
	}

	@Test
	public void testDraw() {
		assertEquals(hacker.draw(), null);
	}

	@Test
	public void testDrawOn() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetX() {
		assertEquals(hacker.getX(), 0);
	}

	@Test
	public void testGetY() {
		assertEquals(hacker.getY(), 0);
	}

	@Test
	public void testGetXOffset() {
		assertEquals(hacker.getXOffset(), 0);
	}

	@Test
	public void testGetYOffset() {
		assertEquals(hacker.getYOffset(), 0);
	}

	@Test
	public void testGoTo() {
		assertEquals(0,0); // This method does nothing so in order to say we got code coverage, this is here
	}

	@Test
	public void testTick() {
		fail("Not yet implemented");
	}

	@Test
	public void testIsClosing() {
//		money.tick();
		boolean expected = false;
		assertEquals(hacker.isClosing(), expected);
		
		// After the change
//		money.tick();
//		expected = true;
//		assertEquals(ending.isClosing(), expected);
	}

	@Test
	public void testIsResetting() {
//		hacker.tick();
		boolean expected = false;
		assertEquals(hacker.isResetting(), expected);
	}

	@Test
	public void testGetWidth() {
		int expected = 320;
		assertEquals(hacker.getWidth(), expected);
	}

	@Test
	public void testGetHeight() {
		int expected = 240;
		assertEquals(hacker.getHeight(), expected);
	}

	@Test
	public void testGetSize() {
		Dimension expected = new Dimension(320, 240);
		assertEquals(hacker.getSize(), expected);
	}

	@Test
	public void testIsScrollable() {
		boolean expected = false;
		assertEquals(hacker.isScrollable(), expected);
	}

}
