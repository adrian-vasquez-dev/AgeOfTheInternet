//package pitzik4.ageOfTheInternet.test.cutScenes;
//
//import pitzik4.ageOfTheInternet.cutScenes.EndingCutscene;
//
//import static org.junit.Assert.*;
//
//import org.junit.After;
//import org.junit.AfterClass;
//import org.junit.Before;
//import org.junit.BeforeClass;
//import org.junit.Test;
//
//public class EndingCutsceneTest() {
//
//}