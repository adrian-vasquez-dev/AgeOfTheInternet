//package pitzik4.ageOfTheInternet.test;
//
//import org.junit.runners.Suite.SuiteClasses;
//import org.junit.runners.Suite;
//import org.junit.runner.RunWith;
//
//@RunWith(Suite.class)
//@SuiteClasses({cutScenes.EndingCutsceneTest.class,
//               cutScenes.HackerCutsceneTest.class,
//               cutScenes.MoneyCutsceneTest.class,
//               cutScenes.StartingCutsceneTest.class,
//               gameLogic.ButtonTest.class,
//               gameLogic.GameTest.class,
//               gameLogic.HackerTest.class,
//               gameLogic.LevelTest.class,
//               gameLogic.LoseScreenTest.class,
//               gameLogic.MenuTest.class,
//               gameLogic.PauseScreenTest.class,
//               gameLogic.PlayerTest.class,
//               gameLogic.RenderableTickableTest.class,
//               gameLogic.StageTest.class,
//               gameLogic.TickableTest.class,
//               gameLogic.TitleScreenTest.class,
//               gameLogic.XButtonTest.class,
//               graphics.AnimationTest.class,
//               graphics.BackgroundTest.class,
//               graphics.BlueFrameTest.class,
//               graphics.ConfettiParticleTest.class,
//               graphics.ExplosionParticleTest.class,
//               graphics.InfoBoxTest.class,
//               graphics.MoneyParticleTest.class,
//               graphics.RenderableStringTest.class,
//               graphics.ScreenTest.class,
//               graphics.SpriteTest.class,
//               tiles.BrokenConnectionTileTest.class,
//               tiles.ChurchTileTest.class,
//               tiles.ComputerTileTest.class,
//               tiles.ConnectionTest.class,
//               tiles.CorporationTest.class,
//               tiles.EndTileTest.class,
//               tiles.HackerTileTest.class,
//               tiles.HomeTileTest.class,
//               tiles.TileTest.class,
//               })
//
//public class LabTestSuite {
//
//}
