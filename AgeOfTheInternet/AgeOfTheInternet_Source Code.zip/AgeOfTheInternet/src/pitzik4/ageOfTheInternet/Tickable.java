package pitzik4.ageOfTheInternet;

public interface Tickable {
	public void tick();
}
